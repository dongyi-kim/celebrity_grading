This repo contains the Amelia Bootstrap theme used in [Getting MEAN](http://www.manning.com/sholmes/).

It was originally created by [Bootswatch](http://bootswatch.com/) but has since been deprecated and removed from their site. Hence hosting it on GitHub.